import json
import requests
from bs4 import BeautifulSoup
def lambda_handler(event, context):
    video_id = event['video_id']
    video_url= "https://www.imdb.com/video/"+video_id
    print(video_url)
    r = requests.get(url=video_url)
    soup = BeautifulSoup(r.text, 'html.parser')
    script =soup.find("script",{'type': 'application/json'})
    json_object = json.loads(script.string)
    # print(json_object["props"]["pageProps"]["videoPlaybackData"]["video"]["playbackURLs"])
    videos = json_object["props"]["pageProps"]["videoPlaybackData"]["video"]["playbackURLs"]
    # links video quality order auto,1080,720

    for video in videos[1:] :
        video_link = video["url"]
        print("video_link",video_link)  
        break
    video_link= videos[1:]
    return {
        'statusCode': 200,
        'body': json.dumps(video_link)
    }
